# Railway AI Decision Support Prototype

This repository contains a prototype implementation of an AI–assisted
railway dispatching system. It demonstrates how synthetic data,
machine learning, optimisation and simulation can be combined to
support traffic controllers in maximising throughput and minimising
delays on a railway corridor.

> **Disclaimer:** The data and models in this project are synthetic and
> designed solely for prototyping. They are **not** based on real
> operational information from Indian Railways or any other network.

## Contents

The repository is organised into several modules under the
`railway_ai` package:

| Module                     | Purpose                                                         |
|----------------------------|-----------------------------------------------------------------|
| `dataset_generator.py`     | Builds a synthetic rail corridor (stations, sections and trains) and writes CSV and JSON files. |
| `delay_prediction_model.py`| Trains and applies a RandomForest model to forecast arrival delays. |
| `optimizer.py`             | Formulates a mixed integer linear program to re–schedule trains given run–time, dwell and headway constraints. |
| `simulator.py`             | Uses SimPy to simulate train movements from an optimised schedule, optionally injecting disruptions. |
| `server.py`                | Exposes the above capabilities as a REST API via FastAPI. |
| `__init__.py`              | Declares the package and documents high level functionality. |

## Getting Started

### 1. Install Dependencies

This project uses Python 3.10+ and requires a few scientific and web
libraries. Create a virtual environment and install from
`requirements.txt`:

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 2. Generate Synthetic Data

Run the dataset generator to produce a set of CSV and JSON files under
`synthetic_data/` (by default). These include station lists, section
connections, a train roster and an ideal timetable seed.

```bash
python -m railway_ai.dataset_generator --output-dir synthetic_data
```

### 3. Train the Delay Model

Train a RandomForest regressor on the synthetic timetable to forecast
arrival delays. The model will be saved as `delay_model.joblib` in
your working directory.

```bash
python -m railway_ai.delay_prediction_model --data-dir synthetic_data --train
```

### 4. Optimise the Schedule

Use the MILP scheduler to compute an optimised timetable. You can
simulate current delays or insert a new train by passing JSON strings
for the appropriate parameters. The result is a CSV with arrival and
departure times for each train at each station.

```bash
python -m railway_ai.optimizer --data-dir synthetic_data --output optimised_schedule.csv

# Example with current delays (train 1 delayed by 10 minutes) and a new train
python -m railway_ai.optimizer \
  --data-dir synthetic_data \
  --current-delays '{"1": 10}' \
  --new-train '{"name": "SPECIAL01", "train_type": "EXPRESS", "priority": 3, "direction": 1, "earliest_departure_min": 420}' \
  --output reschedule.csv
```

### 5. Run a Simulation

Replay an optimised schedule to observe actual timings under
constraints. Optional disruptions can be injected; these close a
section between two stations for a duration (in minutes). The result
includes actual arrival/departure times and computed delays.

```bash
python -m railway_ai.simulator \
  --data-dir synthetic_data \
  --schedule optimised_schedule.csv \
  --disruptions '[{"section_id": 5, "start_min": 180.0, "duration_min": 30.0, "description": "maintenance"}]' \
  --output simulation_results.csv
```

### 6. Launch the API

Start the FastAPI server to expose prediction, optimisation, simulation
and recommendation endpoints. If the synthetic data or delay model are
missing they will be generated automatically on startup.

```bash
uvicorn railway_ai.server:app --reload
```

You can then interact with the API at `http://localhost:8000`.

### 7. Request Recommendations

Given a baseline schedule (e.g. the seed timetable) and an optimised
schedule, the `/recommendations` endpoint returns human–readable
suggestions such as holding or advancing a train at a station to
achieve the optimised plan. This can be used to translate raw
optimisation output into actionable instructions for a dispatcher.

## Example Workflow

1. Generate the dataset and train the delay model.
2. Retrieve the seed timetable from `timetable_seed.csv`.
3. Predict delays for the seed timetable using `/predict_delay` and
   decide whether re–scheduling is required.
4. Optimise the schedule with `/optimize_schedule` (optionally
   passing current delays or adding a new train).
5. Simulate the optimised schedule under various disruptions using
   `/simulate` to assess robustness.
6. Generate controller recommendations with `/recommendations` to
   communicate the AI’s decisions to a human dispatcher.

This prototype demonstrates how AI and operations research can
proactively manage rail traffic, but it is by no means a complete
solution. Extending it to real networks would require richer data,
tighter integration with signalling and interlocking systems, and
extensive validation for safety and correctness.