"""Top level package for the railway AI decision support system.

This package contains modules to generate synthetic railway data, train and
apply delay prediction models, perform schedule optimisation and simulate
operations on a rail corridor. The code is organised into separate
modules so each concern (data, machine learning, optimisation and
simulation) can be developed and tested independently.

The overall goal is to provide a decision support tool that can assist
traffic controllers by forecasting delays, suggesting conflict
resolutions and evaluating ‘what‐if’ scenarios through simulation. A
reference FastAPI server is also provided to expose these capabilities
as HTTP endpoints.

Usage examples can be found in the README.md file at the root of the
repository.
"""

__all__ = [
    "dataset_generator",
    "delay_prediction_model",
    "optimizer",
    "simulator",
    "server",
]