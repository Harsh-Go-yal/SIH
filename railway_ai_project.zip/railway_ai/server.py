"""FastAPI application exposing the railway decision support capabilities.

This module sets up a web API that wraps the functionality of the
synthetic dataset, delay prediction model, optimiser and simulator. It
provides endpoints for:

* `/predict_delay` – predict delays for given schedule records.
* `/optimize_schedule` – compute an optimised timetable given current
  delays or a new train insertion.
* `/simulate` – run a simulation of a provided schedule, optionally
  injecting disruptions.
* `/recommendations` – compare a baseline schedule against an optimised
  one and produce human–readable suggestions for the controller.

The server loads the synthetic dataset and a trained delay model on
startup. If the dataset or model are missing it will attempt to
generate/train them. All file paths can be configured via environment
variables or passed in explicitly when initialising the app.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import pandas as pd

from . import dataset_generator as dg
from . import delay_prediction_model as dpm
from . import optimizer as opt
from . import simulator as sim


DATA_DIR_ENV = "RAILWAY_DATA_DIR"
MODEL_PATH_ENV = "RAILWAY_MODEL_PATH"


def _ensure_data_and_model(data_dir: Path, model_path: Path) -> None:
    """Ensure that the synthetic data and delay model exist.

    If any of the required CSV files or the model file are missing,
    attempt to generate them. This function is idempotent.
    """
    # Generate dataset if missing
    required_files = [
        data_dir / "stations.csv",
        data_dir / "sections.csv",
        data_dir / "trains.csv",
        data_dir / "timetable_seed.csv",
        data_dir / "rules.json",
    ]
    if not all(p.exists() for p in required_files):
        print(f"Generating synthetic data in {data_dir}...")
        dg.generate_dataset(data_dir)
    # Train model if missing
    if not model_path.exists():
        print(f"Training delay model and saving to {model_path}...")
        mae = dpm.train_delay_model(
            data_dir / "stations.csv",
            data_dir / "trains.csv",
            data_dir / "timetable_seed.csv",
            model_path=model_path,
            random_state=42,
        )
        print(f"Delay model trained (MAE={mae:.2f})")


class DelayRequest(BaseModel):
    records: List[Dict[str, Any]] = Field(..., description="List of schedule records with keys train_id, station_id, scheduled_arrival (minutes since midnight) and optionally day_of_week")


class OptimizeRequest(BaseModel):
    current_delays: Optional[Dict[int, float]] = Field(None, description="Mapping from train_id to additional delay in minutes")
    new_train: Optional[Dict[str, Any]] = Field(None, description="Optional new train to insert into the schedule (must mirror trains.csv fields)")


class ScheduleResponse(BaseModel):
    schedule: List[Dict[str, Any]]


class SimulateRequest(BaseModel):
    schedule: List[Dict[str, Any]]
    disruptions: Optional[List[Dict[str, Any]]] = Field(None, description="List of disruptions with keys section_id, start_min, duration_min, description")


class SimulationResponse(BaseModel):
    results: List[Dict[str, Any]]


class RecommendationRequest(BaseModel):
    baseline_schedule: List[Dict[str, Any]]
    optimised_schedule: List[Dict[str, Any]]


class Recommendation(BaseModel):
    train_id: int
    station_id: int
    suggestion: str


class RecommendationsResponse(BaseModel):
    recommendations: List[Recommendation]


def create_app(data_dir: Optional[str] = None, model_path: Optional[str] = None) -> FastAPI:
    """Create and return a FastAPI application with preloaded assets."""
    # Determine data and model locations
    data_dir = Path(data_dir or os.getenv(DATA_DIR_ENV, "./synthetic_data"))
    model_path = Path(model_path or os.getenv(MODEL_PATH_ENV, "delay_model.joblib"))
    # Ensure dataset and model exist
    _ensure_data_and_model(data_dir, model_path)
    # Load static resources
    stations_df = pd.read_csv(data_dir / "stations.csv")
    sections_df = pd.read_csv(data_dir / "sections.csv")
    trains_df = pd.read_csv(data_dir / "trains.csv")
    timetable_df = pd.read_csv(data_dir / "timetable_seed.csv")
    with open(data_dir / "rules.json", "r", encoding="utf-8") as f:
        rules: Dict[str, Any] = json.load(f)
    # Load delay model
    model = dpm.load_delay_model(model_path)
    app = FastAPI(title="Railway AI Decision Support API")

    # Helper to build feature dataframe
    def _build_features(records: List[Dict[str, Any]]) -> pd.DataFrame:
        return dpm.build_feature_dataframe(records, trains_df)

    @app.post("/predict_delay")
    async def predict_delay(req: DelayRequest) -> Dict[str, List[float]]:
        feature_df = _build_features(req.records)
        preds = dpm.predict_delay(model, feature_df)
        return {"predicted_delays": preds.tolist()}

    @app.post("/optimize_schedule", response_model=ScheduleResponse)
    async def optimise_endpoint(req: OptimizeRequest) -> ScheduleResponse:
        schedule_df = opt.optimise_schedule(
            trains_df,
            stations_df,
            sections_df,
            rules,
            current_delays=req.current_delays,
            new_train=req.new_train,
        )
        return ScheduleResponse(schedule=schedule_df.to_dict("records"))

    @app.post("/simulate", response_model=SimulationResponse)
    async def simulate_endpoint(req: SimulateRequest) -> SimulationResponse:
        schedule_df = pd.DataFrame(req.schedule)
        # Validate schedule columns
        if not {"train_id", "station_id", "arrival_min", "departure_min"}.issubset(schedule_df.columns):
            raise HTTPException(status_code=400, detail="Schedule records must include train_id, station_id, arrival_min and departure_min")
        # Convert disruptions
        disruptions = None
        if req.disruptions:
            disruptions = [
                sim.Disruption(
                    section_id=int(d["section_id"]),
                    start_min=float(d["start_min"]),
                    duration_min=float(d["duration_min"]),
                    description=d.get("description", ""),
                )
                for d in req.disruptions
            ]
        result_df = sim.simulate_schedule(schedule_df, sections_df, trains_df, rules, disruptions)
        return SimulationResponse(results=result_df.to_dict("records"))

    def _generate_recommendations(
        baseline: pd.DataFrame, optimised: pd.DataFrame
    ) -> List[Recommendation]:
        # Merge on train_id and station_id; compute differences
        merged = baseline.merge(
            optimised,
            on=["train_id", "station_id"],
            suffixes=("_base", "_opt"),
            how="inner",
        )
        recs: List[Recommendation] = []
        for _, row in merged.iterrows():
            t_id = int(row["train_id"])
            s_id = int(row["station_id"])
            base_depart = row.get("departure_min_base")
            opt_depart = row.get("departure_min_opt")
            base_arr = row.get("arrival_min_base")
            opt_arr = row.get("arrival_min_opt")
            suggestion = None
            # If departure time changed
            if not pd.isnull(base_depart) and not pd.isnull(opt_depart):
                diff = opt_depart - base_depart
                if abs(diff) >= 1e-2:  # consider differences >0.01 min
                    if diff > 0:
                        suggestion = f"Hold train for {diff:.1f} min at station {s_id}"
                    else:
                        suggestion = f"Advance train by {abs(diff):.1f} min at station {s_id}"
            # If arrival time changed but departure didn't, use arrival difference
            if suggestion is None and not pd.isnull(base_arr) and not pd.isnull(opt_arr):
                diff = opt_arr - base_arr
                if abs(diff) >= 1e-2:
                    if diff > 0:
                        suggestion = f"Train expected {diff:.1f} min later at station {s_id}"
                    else:
                        suggestion = f"Train expected {abs(diff):.1f} min earlier at station {s_id}"
            if suggestion:
                recs.append(Recommendation(train_id=t_id, station_id=s_id, suggestion=suggestion))
        return recs

    @app.post("/recommendations", response_model=RecommendationsResponse)
    async def recommendations_endpoint(req: RecommendationRequest) -> RecommendationsResponse:
        base_df = pd.DataFrame(req.baseline_schedule)
        opt_df = pd.DataFrame(req.optimised_schedule)
        recs = _generate_recommendations(base_df, opt_df)
        return RecommendationsResponse(recommendations=recs)

    return app


# Instantiate the application for ASGI servers (e.g. uvicorn)
app = create_app()