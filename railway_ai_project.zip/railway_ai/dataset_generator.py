"""Synthetic railway dataset generator.

This module produces a self–contained set of CSV files and a JSON
configuration suitable for prototyping an AI powered railway dispatch
solution. The generated data approximates a single corridor between
Pune and Nagpur, with a handful of intermediate stations, sections and
mixed train services. The output consists of:

* ``stations.csv`` – ordered list of stations with kilometre markers
  and platform counts.
* ``sections.csv`` – adjacency list connecting stations along the line,
  including base run times and number of parallel tracks.
* ``trains.csv`` – roster of train services with type, priority,
  direction and earliest departure times.
* ``timetable_seed.csv`` – ideal timetable derived from the base run
  times and train speed factors.
* ``rules.json`` – general operational parameters (headways, dwell
  times, speed factors and objective weights).

These files form the foundation for downstream modules such as the
scheduler and simulator. Since Indian Railways data is not publicly
available at this granularity, we construct plausible synthetic
statistics based on typical run times and station distances. You can
modify the lists below to adapt the dataset to other corridors or
increase the number of trains.
"""

from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List

import pandas as pd


@dataclass
class Station:
    id: int
    name: str
    distance_km: float
    platforms: int


@dataclass
class Section:
    id: int
    from_station_id: int
    to_station_id: int
    distance_km: float
    base_runtime_min: float
    tracks: int


@dataclass
class Train:
    id: int
    name: str
    train_type: str
    priority: int
    direction: int
    earliest_departure_min: int  # minutes since midnight


def build_default_stations() -> List[Station]:
    """Return a list of stations along the synthetic Pune–Nagpur corridor.

    Distances are cumulative kilometres from Pune. Platform counts are
    chosen to reflect station size.
    """
    names = [
        ("PUNE", 0.0, 4),
        ("ANG", 75.0, 2),
        ("MIB", 146.0, 2),
        ("SGA", 220.0, 2),
        ("BD", 298.0, 2),
        ("AM", 388.0, 3),
        ("AB", 471.0, 1),
        ("BSL", 544.0, 3),
        ("IGU", 620.0, 2),
        ("NGP", 785.0, 5),
    ]
    return [Station(idx + 1, name, dist, platforms) for idx, (name, dist, platforms) in enumerate(names)]


def build_default_sections() -> List[Section]:
    """Return a list of track sections connecting the default stations.

    Base run times are based on distance / average speed assumptions and
    include safety margins. The ``tracks`` field specifies the number
    of parallel tracks – a value of 1 means trains must coordinate to
    pass each other, while 2 allows simultaneous bidirectional running.
    """
    # (from_id, to_id, distance_km, base_runtime_min, tracks)
    entries = [
        (1, 2, 75.0, 70.0, 1),  # Pune – Ang
        (2, 3, 71.0, 68.0, 1),  # Ang – Mib
        (3, 4, 74.0, 72.0, 2),  # Mib – Sga
        (4, 5, 78.0, 77.0, 2),  # Sga – Bd
        (5, 6, 90.0, 85.0, 2),  # Bd – Am (busy section)
        (6, 7, 83.0, 80.0, 2),  # Am – Ab
        (7, 8, 73.0, 70.0, 1),  # Ab – Bsl
        (8, 9, 76.0, 73.0, 2),  # Bsl – Igu
        (9, 10, 165.0, 150.0, 2),  # Igu – Ngp (long haul)
    ]
    return [Section(idx + 1, from_id, to_id, dist, runtime, tracks) for idx, (from_id, to_id, dist, runtime, tracks) in enumerate(entries)]


def build_default_trains() -> List[Train]:
    """Return a list of synthetic train services on the corridor.

    Each train has a type (Superfast, Express, Mail, Passenger or Freight),
    an associated priority, a direction (1 for downline Pune→Nagpur,
    -1 for uplink) and an earliest departure time from its origin
    (expressed as minutes since midnight). The times are staggered to
    avoid immediate conflicts in the seed timetable; scheduling logic
    will adjust them as necessary.
    """
    trains = [
        (1, "SF101", "SUPERFAST", 5, 1, 6 * 60),  # 06:00
        (2, "EXP201", "EXPRESS", 4, 1, 6 * 60 + 15),  # 06:15
        (3, "MAIL301", "MAIL", 3, 1, 6 * 60 + 30),  # 06:30
        (4, "FRT401", "FREIGHT", 2, 1, 6 * 60 + 45),  # 06:45
        (5, "PASS501", "PASSENGER", 1, 1, 7 * 60),  # 07:00
        (6, "SF102", "SUPERFAST", 5, -1, 6 * 60),  # 06:00 (return)
        (7, "EXP202", "EXPRESS", 4, -1, 6 * 60 + 20),  # 06:20
        (8, "MAIL302", "MAIL", 3, -1, 6 * 60 + 40),  # 06:40
        (9, "FRT402", "FREIGHT", 2, -1, 7 * 60),  # 07:00
        (10, "PASS502", "PASSENGER", 1, -1, 7 * 60 + 20),  # 07:20
    ]
    return [Train(*tup) for tup in trains]


def build_rules() -> Dict:
    """Return a dictionary of operational rules for the synthetic corridor.

    This includes headway times (minimum separation between trains on
    the same section), dwell times at stations based on train type,
    speed factors (multiplier on base run times) and weight factors
    used in the optimisation objective. These parameters may be tuned to
    experiment with different priorities (e.g. favouring throughput vs.
    punctuality).
    """
    return {
        "headway_minutes": 5.0,
        "dwell_minutes": {
            "SUPERFAST": 5.0,
            "EXPRESS": 7.0,
            "MAIL": 8.0,
            "FREIGHT": 15.0,
            "PASSENGER": 10.0,
        },
        "speed_factors": {
            "SUPERFAST": 1.2,
            "EXPRESS": 1.0,
            "MAIL": 0.9,
            "FREIGHT": 0.7,
            "PASSENGER": 0.8,
        },
        "objective_weights": {
            "delay": 1.0,
            "throughput": -0.05,
        },
        # Rolling horizon length in minutes for real–time optimisation
        "rolling_horizon_minutes": 120,
    }


def write_csv(path: Path, header: List[str], rows: List[List]):
    """Write a simple CSV file given header and rows."""
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(rows)


def generate_dataset(output_dir: Path | str = ".") -> None:
    """Generate all synthetic data files into the specified directory.

    This function orchestrates building the default lists, computing the
    ideal timetable based on run times and speed factors, and serialising
    everything to disk. If the directory does not exist it will be
    created.

    :param output_dir: target directory to write the files to
    """
    outdir = Path(output_dir)
    outdir.mkdir(parents=True, exist_ok=True)

    stations = build_default_stations()
    sections = build_default_sections()
    trains = build_default_trains()
    rules = build_rules()

    # Write stations
    write_csv(
        outdir / "stations.csv",
        ["id", "name", "distance_km", "platforms"],
        [[s.id, s.name, s.distance_km, s.platforms] for s in stations],
    )
    # Write sections
    write_csv(
        outdir / "sections.csv",
        ["id", "from_station_id", "to_station_id", "distance_km", "base_runtime_min", "tracks"],
        [[sec.id, sec.from_station_id, sec.to_station_id, sec.distance_km, sec.base_runtime_min, sec.tracks] for sec in sections],
    )
    # Write trains
    write_csv(
        outdir / "trains.csv",
        ["id", "name", "train_type", "priority", "direction", "earliest_departure_min"],
        [
            [t.id, t.name, t.train_type, t.priority, t.direction, t.earliest_departure_min]
            for t in trains
        ],
    )
    # Compute seed timetable: only arrival/departure times at each station for each train
    # We'll use base run times and speed factors; assume symmetric distances for both directions.
    timetable_rows: List[List] = []
    for train in trains:
        factor = rules["speed_factors"][train.train_type]
        dwell = rules["dwell_minutes"][train.train_type]
        # Determine route order based on direction
        if train.direction == 1:
            route = stations
        else:
            route = list(reversed(stations))
        current_time = train.earliest_departure_min
        for idx, station in enumerate(route):
            # Arrival time equals current_time for the first station; otherwise add travel time
            if idx == 0:
                arrival = current_time
            else:
                prev_section = next(
                    s for s in sections
                    if (s.from_station_id == route[idx - 1].id and s.to_station_id == station.id)
                    or (s.to_station_id == route[idx - 1].id and s.from_station_id == station.id)
                )
                # Travel time scaled by train factor
                travel_time = prev_section.base_runtime_min / factor
                current_time += travel_time
                arrival = current_time
            departure = arrival + dwell
            timetable_rows.append([
                train.id,
                station.id,
                int(arrival),
                int(departure),
            ])
            current_time = departure
    # Write timetable
    write_csv(
        outdir / "timetable_seed.csv",
        ["train_id", "station_id", "arrival_min", "departure_min"],
        timetable_rows,
    )
    # Write rules
    with (outdir / "rules.json").open("w", encoding="utf-8") as f:
        json.dump(rules, f, indent=2)

    print(f"Synthetic dataset generated in {outdir.resolve()}")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Generate synthetic railway dataset")
    parser.add_argument(
        "--output-dir",
        type=str,
        default="./synthetic_data",
        help="Directory to store generated files",
    )
    args = parser.parse_args()
    generate_dataset(args.output_dir)