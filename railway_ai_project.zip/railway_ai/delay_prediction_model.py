"""Machine learning model for predicting train delays.

This module provides utilities to train and use a delay prediction
model. Because real historical delay data is not available in this
prototype, we synthesise training labels by perturbing the ideal
timetable with random noise. In a real deployment, you would replace
``generate_training_samples`` with code that loads actual arrival
timestamps and computes the difference from the scheduled times. The
model itself is a RandomForestRegressor which can capture nonlinear
relationships between features.

Training features used here include:

* train_type encoded as an integer category
* station_id
* scheduled arrival time (minutes since midnight)
* day_of_week (assumed fixed for synthetic data)
* direction (1 or -1)

The target variable is the arrival delay in minutes. The trained model
is persisted to disk via ``joblib``. To serve predictions, load the
model and call ``predict_delay`` on a DataFrame with matching feature
columns.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable, Optional, Tuple

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error


def load_data(
    stations_path: Path | str,
    trains_path: Path | str,
    timetable_path: Path | str,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Load the core CSV files into pandas DataFrames."""
    stations = pd.read_csv(stations_path)
    trains = pd.read_csv(trains_path)
    timetable = pd.read_csv(timetable_path)
    return stations, trains, timetable


def _encode_train_type(train_type: str) -> int:
    mapping = {
        "SUPERFAST": 0,
        "EXPRESS": 1,
        "MAIL": 2,
        "FREIGHT": 3,
        "PASSENGER": 4,
    }
    return mapping.get(train_type, len(mapping))


def generate_training_samples(
    stations: pd.DataFrame,
    trains: pd.DataFrame,
    timetable: pd.DataFrame,
    random_state: Optional[int] = None,
) -> pd.DataFrame:
    """Construct a synthetic dataset of features and target delays.

    We join the timetable with train attributes and assign random delay
    values. The magnitude of the noise depends on the train type: more
    unpredictable services (freight and passenger) are given larger
    standard deviations. This synthetic target is purely for model
    demonstration and not reflective of real railway performance.
    """
    rng = np.random.default_rng(random_state)
    # Map train_id -> row in trains
    train_map = trains.set_index("id").to_dict("index")
    rows = []
    for _, tt_row in timetable.iterrows():
        train = train_map[int(tt_row["train_id"])]
        # Build feature row
        train_type = train["train_type"]
        type_code = _encode_train_type(train_type)
        station_id = int(tt_row["station_id"])
        sched_arr = float(tt_row["arrival_min"])
        direction = int(train["direction"])
        # synthetic noise: base sigma increases with train type index
        sigma_map = {0: 1.5, 1: 2.5, 2: 3.0, 3: 5.0, 4: 4.0}
        sigma = sigma_map.get(type_code, 3.0)
        delay = float(rng.normal(loc=0.0, scale=sigma))
        rows.append(
            {
                "train_id": int(tt_row["train_id"]),
                "station_id": station_id,
                "train_type_code": type_code,
                "scheduled_arrival": sched_arr,
                "direction": direction,
                # Fixed day_of_week (0 = Monday) since synthetic data is static
                "day_of_week": 0,
                "delay_min": delay,
            }
        )
    return pd.DataFrame(rows)


def train_delay_model(
    stations_path: Path | str,
    trains_path: Path | str,
    timetable_path: Path | str,
    model_path: Path | str = "delay_model.joblib",
    test_size: float = 0.2,
    random_state: Optional[int] = None,
) -> float:
    """Train a RandomForestRegressor on the synthetic data and save it.

    :param stations_path: path to stations.csv (unused but kept for future ext)
    :param trains_path: path to trains.csv
    :param timetable_path: path to timetable_seed.csv
    :param model_path: target path to write the trained model
    :param test_size: fraction of data to reserve for validation
    :param random_state: seed for reproducibility
    :return: mean absolute error on the validation set
    """
    stations, trains, timetable = load_data(stations_path, trains_path, timetable_path)
    df = generate_training_samples(stations, trains, timetable, random_state)
    feature_cols = ["train_type_code", "station_id", "scheduled_arrival", "direction", "day_of_week"]
    X = df[feature_cols]
    y = df["delay_min"]
    X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=test_size, random_state=random_state)
    model = RandomForestRegressor(n_estimators=100, random_state=random_state)
    model.fit(X_train, y_train)
    preds = model.predict(X_val)
    mae = mean_absolute_error(y_val, preds)
    # Save model
    joblib.dump(model, model_path)
    return mae


def load_delay_model(model_path: Path | str = "delay_model.joblib") -> RandomForestRegressor:
    """Load a previously trained delay model from disk."""
    model: RandomForestRegressor = joblib.load(model_path)
    return model


def build_feature_dataframe(
    train_records: Iterable[dict],
    trains_df: pd.DataFrame,
) -> pd.DataFrame:
    """Create a feature DataFrame from provided schedule records.

    Each record should include ``train_id``, ``station_id`` and
    ``scheduled_arrival``. Missing optional fields (direction, day_of_week)
    will be looked up in ``trains_df`` or defaulted to zero. The returned
    DataFrame will have the columns expected by the model.
    """
    # Map train_id -> direction and type code
    train_info = trains_df.set_index("id").to_dict("index")
    rows = []
    for rec in train_records:
        t_id = int(rec["train_id"])
        info = train_info.get(t_id, {})
        type_code = _encode_train_type(info.get("train_type", "EXPRESS"))
        direction = int(info.get("direction", 1))
        station_id = int(rec["station_id"])
        sched_arr = float(rec["scheduled_arrival"])
        day_of_week = int(rec.get("day_of_week", 0))
        rows.append(
            {
                "train_type_code": type_code,
                "station_id": station_id,
                "scheduled_arrival": sched_arr,
                "direction": direction,
                "day_of_week": day_of_week,
            }
        )
    return pd.DataFrame(rows)


def predict_delay(
    model: RandomForestRegressor,
    feature_df: pd.DataFrame,
) -> np.ndarray:
    """Predict delays (in minutes) for the given feature DataFrame."""
    return model.predict(feature_df)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Train or use the delay prediction model")
    parser.add_argument("--data-dir", type=str, default="./synthetic_data", help="Directory containing input CSV files")
    parser.add_argument("--model-path", type=str, default="delay_model.joblib", help="Path to output or load model")
    parser.add_argument("--train", action="store_true", help="Train the model")
    parser.add_argument("--predict", action="store_true", help="Run predictions on the seed timetable")
    args = parser.parse_args()
    data_dir = Path(args.data_dir)
    if args.train:
        mae = train_delay_model(
            data_dir / "stations.csv",
            data_dir / "trains.csv",
            data_dir / "timetable_seed.csv",
            model_path=args.model_path,
            random_state=42,
        )
        print(f"Trained delay model saved to {args.model_path}; validation MAE: {mae:.2f} minutes")
    if args.predict:
        model = load_delay_model(args.model_path)
        _, trains_df, timetable_df = load_data(
            data_dir / "stations.csv", data_dir / "trains.csv", data_dir / "timetable_seed.csv"
        )
        feat_df = build_feature_dataframe(
            timetable_df.to_dict("records"),
            trains_df,
        )
        preds = predict_delay(model, feat_df)
        print(pd.DataFrame({"train_id": timetable_df["train_id"], "station_id": timetable_df["station_id"], "predicted_delay": preds}))