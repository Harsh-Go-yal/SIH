"""Event-driven simulation of train operations using SimPy.

This module allows you to simulate the movement of trains along a
railway corridor using a schedule produced by the optimiser. Each
section between stations is modelled as a resource with unit capacity
(one train at a time) to capture the constraint that trains cannot
occupy the same block concurrently. The simulation tracks actual
arrival and departure times and can introduce disruptions such as
section closures or additional delays.

By replaying schedules in a simulated environment you can evaluate
performance metrics (average delay, throughput) and test the impact
of various disruption scenarios before deploying the timetable. The
simulation engine is separate from optimisation so you can swap
schedulers or plug in empirical predictions easily.
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Tuple

import pandas as pd
import simpy


@dataclass
class Disruption:
    section_id: int
    start_min: float
    duration_min: float
    description: str = ""


def simulate_schedule(
    schedule_df: pd.DataFrame,
    sections_df: pd.DataFrame,
    trains_df: pd.DataFrame,
    rules: Dict,
    disruptions: Optional[List[Disruption]] = None,
) -> pd.DataFrame:
    """Run a discrete-event simulation of trains following the given schedule.

    :param schedule_df: DataFrame containing columns ``train_id``,
      ``station_id``, ``arrival_min``, ``departure_min`` as produced by
      ``optimizer.optimise_schedule``.
    :param sections_df: DataFrame describing track sections. Each row
      must contain ``id``, ``from_station_id``, ``to_station_id`` and
      ``base_runtime_min``. For the simulation we assume a single unit
      capacity per section; multi-track can be simulated by adjusting
      ``capacity`` below.
    :param trains_df: DataFrame describing trains; used to look up
      train type and hence run-time scaling from rules.
    :param rules: dictionary with keys ``speed_factors`` for per-type
      speed multipliers; ``dwell_minutes`` is not used here because the
      dwell is already baked into ``schedule_df``.
    :param disruptions: optional list of Disruption objects that
      temporarily close sections. During a disruption the resource
      capacity of the affected section is set to zero, causing trains
      to queue until the disruption ends.
    :return: DataFrame with actual arrival and departure times (min) for
      each train and station, along with computed delay in minutes.
    """
    # Build lookups
    # Map section between two stations to id and runtime
    sec_by_pair: Dict[Tuple[int, int], Dict] = {}
    for row in sections_df.itertuples(index=False):
        sec_by_pair[(row.from_station_id, row.to_station_id)] = {
            "id": row.id,
            "runtime": row.base_runtime_min,
        }
        sec_by_pair[(row.to_station_id, row.from_station_id)] = {
            "id": row.id,
            "runtime": row.base_runtime_min,
        }
    # Build schedule by train id: list of (station_id, arrival, departure)
    train_sched: Dict[int, List[Tuple[int, float, float]]] = {}
    for _, row in schedule_df.sort_values(["train_id", "arrival_min"]).iterrows():
        train_sched.setdefault(int(row["train_id"]), []).append(
            (int(row["station_id"]), float(row["arrival_min"]), float(row["departure_min"]))
        )
    # Build speed map
    speed_map = rules.get("speed_factors", {})
    # Initialise environment and resources
    env = simpy.Environment()
    # Each section has a resource. We treat capacity=1 regardless of tracks for simplicity.
    # You could set capacity to the number of tracks in sections_df to allow multiple trains.
    section_resources: Dict[int, simpy.Resource] = {
        row.id: simpy.Resource(env, capacity=1) for row in sections_df.itertuples(index=False)
    }
    # Manage disruptions by maintaining a dictionary of section_id -> list of (start, end)
    disruption_map: Dict[int, List[Tuple[float, float]]] = {}
    if disruptions:
        for dis in disruptions:
            disruption_map.setdefault(dis.section_id, []).append((dis.start_min, dis.start_min + dis.duration_min))
    # Helper to check if a disruption is active on a section at given time
    def is_disrupted(section_id: int, time_min: float) -> bool:
        if section_id not in disruption_map:
            return False
        for start, end in disruption_map[section_id]:
            if start <= time_min < end:
                return True
        return False
    # Record actual times
    result_records: List[Dict] = []
    # Train process
    def train_process(train_id: int, schedule: List[Tuple[int, float, float]]):
        # Wait until the scheduled departure of first station
        first_station, sched_arr, sched_dep = schedule[0]
        # Sleep until scheduled departure or zero if immediate
        yield env.timeout(max(sched_dep, 0))
        current_time = sched_dep
        # Travel through successive stations
        for i in range(len(schedule) - 1):
            s_id, arr_time, dep_time = schedule[i]
            next_id, next_arr, next_dep = schedule[i + 1]
            # Leave station at scheduled departure time (ensuring we haven't overslept)
            depart = max(current_time, dep_time)
            # Acquire section resource
            section_info = sec_by_pair[(s_id, next_id)]
            section_id = section_info["id"]
            # If section is disrupted at our departure time, wait until it reopens
            while is_disrupted(section_id, depart):
                # Wait 1 minute increments until disruption passes
                yield env.timeout(1.0)
                depart += 1.0
            # Record actual departure time
            result_records.append(
                {
                    "train_id": train_id,
                    "station_id": s_id,
                    "scheduled_departure": dep_time,
                    "actual_departure": depart,
                }
            )
            with section_resources[section_id].request() as req:
                yield req
                # Compute run time adjusted by train type
                train_type = trains_df.loc[trains_df["id"] == train_id, "train_type"].iloc[0]
                runtime = section_info["runtime"] / speed_map.get(train_type, 1.0)
                yield env.timeout(runtime)
                current_time = depart + runtime
            # Record actual arrival at next station
            result_records.append(
                {
                    "train_id": train_id,
                    "station_id": next_id,
                    "scheduled_arrival": next_arr,
                    "actual_arrival": current_time,
                }
            )
            # Wait until departure time (dwelling)
            dwell_time = next_dep - next_arr
            # If we arrive early, we may need to wait for dwell; if late, dwell may shrink (simplification)
            wait_time = max(0.0, dwell_time - max(0.0, current_time - next_arr))
            if wait_time > 0:
                yield env.timeout(wait_time)
                current_time += wait_time
        # Completed schedule
    # Launch all train processes
    for train_id, sched in train_sched.items():
        env.process(train_process(train_id, sched))
    env.run(until=1e9)  # large horizon
    # Aggregate actual times by train and station
    records_df = pd.DataFrame(result_records)
    # Merge schedule_df to compute delays
    merged = schedule_df.merge(records_df, on=["train_id", "station_id"], how="left")
    # Compute delays
    if "scheduled_arrival" in merged.columns and "actual_arrival" in merged.columns:
        merged["arrival_delay"] = merged["actual_arrival"] - merged["arrival_min"]
    if "scheduled_departure" in merged.columns and "actual_departure" in merged.columns:
        merged["departure_delay"] = merged["actual_departure"] - merged["departure_min"]
    return merged


if __name__ == "__main__":
    import argparse
    from pathlib import Path
    import json

    parser = argparse.ArgumentParser(description="Simulate train movements from an optimised schedule")
    parser.add_argument("--data-dir", type=str, default="./synthetic_data", help="Directory of input CSV files and schedule")
    parser.add_argument("--schedule", type=str, required=True, help="Path to CSV schedule to simulate")
    parser.add_argument("--rules", type=str, default="rules.json", help="Filename of rules JSON in data directory")
    parser.add_argument("--disruptions", type=str, help="JSON list of disruptions {section_id,start_min,duration_min,description}")
    parser.add_argument("--output", type=str, help="Optional path to write simulation results to CSV")
    args = parser.parse_args()
    data_dir = Path(args.data_dir)
    schedule_df = pd.read_csv(args.schedule)
    sections_df = pd.read_csv(data_dir / "sections.csv")
    trains_df = pd.read_csv(data_dir / "trains.csv")
    with open(data_dir / args.rules, "r", encoding="utf-8") as f:
        rules = json.load(f)
    disruptions = None
    if args.disruptions:
        dis_list = json.loads(args.disruptions)
        disruptions = [Disruption(**d) for d in dis_list]
    sim_df = simulate_schedule(schedule_df, sections_df, trains_df, rules, disruptions)
    if args.output:
        sim_df.to_csv(args.output, index=False)
        print(f"Simulation results written to {args.output}")
    else:
        print(sim_df.head())